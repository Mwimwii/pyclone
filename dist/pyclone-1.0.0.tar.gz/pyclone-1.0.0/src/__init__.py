"""Top-level package for simple-mega."""

__author__ = """Mwila Nyirongo"""
__email__ = 'mpnyirongo@gmail.com'
__version__ = '1.0.0'
