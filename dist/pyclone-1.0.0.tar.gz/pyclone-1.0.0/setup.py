#!/usr/bin/env python

"""The setup script."""

# Available to all python versions
import urllib.request
from setuptools import setup, find_packages
import os
import zipfile
import shutil
import platform
import sys

system = platform.uname().system
machine = platform.uname().machine.lower()

Supported_OS = {'Windows': 'windows', 'Linux': 'linux', 'FreeBSD': 'freebsd',
                'NetBSD': 'netbsd', 'OpenBSD': 'openbsd', 'Darwin': 'osx'}

Supported_Machine = {'x86_64': 'amd64',
                     'amd64': 'amd64', 'x86': '386', 'aarch64': 'arm64'}

is_OS_support = Supported_OS.get(system, 0)
is_Machine_support = Supported_Machine.get(machine, 0)

if 'arm' in machine:
    is_Machine_support = 'arm'
if 'i' and '86' in machine:
    is_Machine_support = '386'
if not (is_Machine_support and is_OS_support):
    print(f'OS or OS type is not supported. Terminating..')
    sys.exit()

# Download and unzip
# print('Downloading Rclone, please wait..')
# download_link = f'https://github.com/rclone/rclone/releases/download/v1.53.1/rclone-v1.53.1-{is_OS_support}-{is_Machine_support}.zip'
# urllib.request.urlretrieve(download_link, 'src/rclone.zip')

os.makedirs('src/rclone', exist_ok=True)
with zipfile.ZipFile('src/rclone.zip', 'r') as zip_ref:
    for name in zip_ref.namelist()[1:]:
        member = zip_ref.open(name)
        with open(os.path.join('src/rclone', os.path.basename(name)), 'wb') as outfile:
            shutil.copyfileobj(member, outfile)

# Create Rclone config in the same diretory, that will be preferred
with open('src/rclone/rclone.conf', 'w') as rclone_config:
    pass
with open('README.md', 'r') as fh:
    long_description = fh.read()

long_description = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa'

setup(
    name='pyclone',
    version='1.0.0',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/Mwimwii/pyclone',

    author='Mwila Nyirongo',
    author_email='mpnyirongo@gmail.com',
    include_package_data=True,
    # package_dir={'': 'src'},
    # package_data={'': ['src/rclone']},
    packages=find_packages(),
    py_modules=['pyclone'],
    python_requires='>=3.2',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: English',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Operating System :: MacOS :: MacOS X,'
        'Operating System :: Microsoft :: Windows,',
        'Operating System :: POSIX :: SunOS/Solaris'
        'Operating System :: Unix',
        'Topic :: Communications :: File Sharing',
        'Topic :: Internet',
        'Topic :: Utilities',

    ],
    description='Python interface for rclone',
    entry_points={
        'console_scripts': [
            'pyclone=src.cli:execute_from_commandline',
        ],
    },
    license='MIT license',
    keywords='pyclone',

    extras_require={
        'dev': [
            'pytest>=3.7'
        ]
    },
)
