"""Unit test package for simple_mega."""
