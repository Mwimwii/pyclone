#!/usr/bin/env python

"""Tests for `simple_mega` package."""

import pytest


def test_command_line_interface():
    pass
